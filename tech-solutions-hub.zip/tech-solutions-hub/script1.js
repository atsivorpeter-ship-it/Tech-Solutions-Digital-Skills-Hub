// 1. Welcome message (Home page)
function showMessage() {
    alert("Welcome to Tech Solutions & Digital Skills Hub!");
}

// 2. Services interaction
function serviceAlert(serviceName) {
    alert("You selected: " + serviceName);
}

// 3. Contact form validation
function validateForm() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let message = document.getElementById("message").value;

    if (name === "" || email === "" || message === "") {
        alert("Please fill in all fields.");
        return false;
    } else {
        alert("Message sent successfully!");
        return true;
    }
}
